# TONxDAO - Auto Hold Bot
This bot I made for my educational purposes.


# HOW TO 
- Get auth data using extension "Telegram Mini App Auth Extractor" in Chrome.
- input auth data in data.txt
- run "pip install -r requirements.txt"
- run "python main.py"